package com.cs320.milestones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cs320Milestones {

	public static void main(String[] args) {
		SpringApplication.run(Cs320Milestones.class, args);
	}

}
