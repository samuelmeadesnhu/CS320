package com.cs320.milestones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mod3milestoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
